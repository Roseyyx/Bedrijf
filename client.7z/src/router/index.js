import { createRouter, createWebHistory } from "vue-router";
import Home from "../pages/Home.vue";
import Admin from "../pages/Admin.vue";
import Products from "../pages/Products.vue";

const routes = [
  {
    path: "/",
    name: "Home",
    component: Home,
  },
  {
    path: "/admin",
    name: "Admin",
    component: Admin,
  },
  {
    path: "/products",
    name: "Products",
    component: Products,
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;