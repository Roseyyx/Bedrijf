<template>
    <AdminComponent/>
</template>

<script>
/*eslint-disable*/
import AdminComponent from '../components/AdminComponent.vue'
export default {
    name: 'Admin',
    components: {
        AdminComponent
    }
}
</script>

<style>
</style>