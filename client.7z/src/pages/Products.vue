<template>
    <ProductComponent/>
</template>

<script>
/*eslint-disable*/
import ProductComponent from '@/components/ProductComponent.vue';
export default {
    name: 'Products',
    components: {
        ProductComponent
    }
}
</script>

<style>
</style>