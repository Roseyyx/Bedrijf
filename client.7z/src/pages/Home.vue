<template>
    <HomeComponent/>
</template>

<script>
/*eslint-disable*/
import HomeComponent from '@/components/HomeComponent.vue';

export default {
    name: 'Home',
    components: {
        HomeComponent
    }
}
</script>

<style>
</style>