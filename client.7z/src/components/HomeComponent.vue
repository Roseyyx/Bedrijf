<!-- @format -->

<template>
	<section>
		<div class="container">
			<div class="showcase" v-for="(product, index) in products" v-bind:item="product" v-bind:index="index" v-bind:key="product._id">
				<div class="product">
					<div class="product-name">
						<h2>{{ product.ProductName }}</h2>
					</div>
					<div class="product-image">
						<img src="@/assets/logo.png" alt="product" />
					</div>
					<div class="product-info">
						<div class="product-price">
							<p>{{ product.ProductPrice }},-</p>
						</div>
						<div class="bezorging">
							<p>Gratis verzending</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</template>

<script>
import ProductService from '../ProductService'

export default {
	name: 'ProductComponent',
	data() {
		return {
			products: [],
			error: '',
			text: ''
		}
	},
	async created() {
		try {
			this.products = await ProductService.getProducts()
		} catch (error) {
			this.error = error.message
		}
	},
	methods: {
		async createProduct() {
			await ProductService.insertProduct(this.text)
			this.products = await ProductService.getProducts()
		},
		async deleteProduct(id) {
			await ProductService.deleteProduct(id)
			this.products = await ProductService.getProducts()
		}
	}
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
section {
	width: 100%;
	height: 100vh;
	background-color: #fff;
	display: flex;
	justify-content: center;
	align-items: center;

	.container {
		width: 70%;
		height: 100%;
		display: flex;
		justify-content: center;
		align-items: center;

		.showcase {
            display: flex;
            flex-wrap: wrap;
            width: 100%;
            justify-content: flex-start;
            align-items: stretch;
            padding: 1rem;
            

			.product {
				border-radius: 10px;
				display: flex;
				flex-direction: column;
				justify-content: center;
				align-items: center;
				padding: 1rem;
				box-shadow: 0 0 10px rgba(0, 0, 0, 0.25);
				background-color: #fff;
				transition: 0.5s ease all;

				.product-name {
					width: 100%;
					height: 100%;
					display: flex;
					justify-content: center;
					align-items: center;

					h1 {
						font-size: 1.5rem;
						font-weight: 500;
					}
				}

				.product-image {
					width: 100%;
					height: 100%;
					display: flex;
					justify-content: center;
					align-items: center;

					img {
						width: 100%;
						height: 100%;
						object-fit: contain;
					}
				}

				.product-info {
					width: 100%;
					height: 100%;
					display: flex;
					flex-direction: column;
					justify-content: center;
					align-items: center;

					.product-price {
						width: 100%;
						height: 100%;
						display: flex;
						justify-content: right;
						align-items: right;
						padding-bottom: 1rem;

						p {
							font-size: 2rem;
							font-weight: 500;
							color: #ff009d;
						}
					}

					.bezorging {
						width: 100%;
						height: 100%;
						display: flex;
						justify-content: center;
						align-items: center;

						p {
							font-size: 0.8rem;
							font-weight: 400;
							color: #3ec378;
						}
					}
				}

				&:hover {
					transform: scale(1.1);
				}
			}
		}
	}
}
</style>
