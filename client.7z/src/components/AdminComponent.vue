<!-- @format -->

<template>
	<div class="container">
		<h1>Product</h1>
        <p class="error" v-if="error">{{ error }}</p>
		<div class="form">
			<input type="text" placeholder="Product Naam" name="ProductName" v-model="form.ProductName"/>
			<input type="text" placeholder="Prijs" name="ProductPrice" v-model="form.ProductPrice"/>
            <input type="text" placeholder="Product Image" name="ProductImage" v-model="form.ProductImage"/>
			<!--<input type="file" placeholder="Afbeelding" name="image" accept="image/png, image/jpeg" />-->
			<button v-on:click="createProduct()">Product Toevoegen</button>
		</div>
	</div>
</template>

<script>
import ProductService from '../ProductService'

export default {
	data() {
		return {
			products: [],
            error: '',
            form: {
				ProductName: '',
				ProductPrice: '',
				ProductImage: '',
			}
		}
	},
	async created() {
		try {
			this.products = await ProductService.getProducts()
		} catch (error) {
			this.error = error.message
		}
	},
    methods: {
		async createProduct() {
			await ProductService.insertProduct(this.form)
			this.products = await ProductService.getProducts()
		},
		async deleteProduct(id) {
			await ProductService.deleteProduct(id)
			this.products = await ProductService.getProducts()
		}
	}
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
.container {
	display: flex;
	flex-direction: column;
	align-items: center;
	justify-content: center;
	height: 100vh;

	div {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}
}
</style>
